

.. _sphx_glr_beginner_blitz_tensor_tutorial.py:


What is PyTorch?
================

It’s a Python based scientific computing package targeted at two sets of
audiences:

-  A replacement for NumPy to use the power of GPUs
-  a deep learning research platform that provides maximum flexibility
   and speed

Getting Started
---------------

Tensors
^^^^^^^

Tensors are similar to NumPy’s ndarrays, with the addition being that
Tensors can also be used on a GPU to accelerate computing.



.. code-block:: python


    from __future__ import print_function
    import torch







Construct a 5x3 matrix, uninitialized:



.. code-block:: python


    x = torch.Tensor(5, 3)
    print(x)





.. rst-class:: sphx-glr-script-out

 Out::

    0.0000e+00 -1.5846e+29  2.1346e-38
     2.0005e+00  3.3034e-30  4.5850e-41
     2.6451e+20  3.7798e-39  0.0000e+00
     0.0000e+00  0.0000e+00  0.0000e+00
     2.1123e-38 -8.5920e+09  2.1353e-38
    [torch.FloatTensor of size 5x3]


Construct a randomly initialized matrix:



.. code-block:: python


    x = torch.rand(5, 3)
    print(x)





.. rst-class:: sphx-glr-script-out

 Out::

    0.1209  0.5228  0.6754
     0.0719  0.0918  0.3483
     0.4919  0.9017  0.8983
     0.6995  0.0736  0.2160
     0.9873  0.4071  0.9028
    [torch.FloatTensor of size 5x3]


Get its size:



.. code-block:: python


    print(x.size())





.. rst-class:: sphx-glr-script-out

 Out::

    torch.Size([5, 3])


.. note::
    ``torch.Size`` is in fact a tuple, so it supports all tuple operations.

Operations
^^^^^^^^^^
There are multiple syntaxes for operations. In the following
example, we will take a look at the addition operation.

Addition: syntax 1



.. code-block:: python

    y = torch.rand(5, 3)
    print(x + y)





.. rst-class:: sphx-glr-script-out

 Out::

    0.1591  1.4408  1.1944
     0.6712  0.7164  0.7274
     0.7410  1.7226  1.2527
     0.8556  0.3704  0.5237
     1.2893  1.0873  1.7814
    [torch.FloatTensor of size 5x3]


Addition: syntax 2



.. code-block:: python


    print(torch.add(x, y))





.. rst-class:: sphx-glr-script-out

 Out::

    0.1591  1.4408  1.1944
     0.6712  0.7164  0.7274
     0.7410  1.7226  1.2527
     0.8556  0.3704  0.5237
     1.2893  1.0873  1.7814
    [torch.FloatTensor of size 5x3]


Addition: providing an output tensor as argument



.. code-block:: python

    result = torch.Tensor(5, 3)
    torch.add(x, y, out=result)
    print(result)





.. rst-class:: sphx-glr-script-out

 Out::

    0.1591  1.4408  1.1944
     0.6712  0.7164  0.7274
     0.7410  1.7226  1.2527
     0.8556  0.3704  0.5237
     1.2893  1.0873  1.7814
    [torch.FloatTensor of size 5x3]


Addition: in-place



.. code-block:: python


    # adds x to y
    y.add_(x)
    print(y)





.. rst-class:: sphx-glr-script-out

 Out::

    0.1591  1.4408  1.1944
     0.6712  0.7164  0.7274
     0.7410  1.7226  1.2527
     0.8556  0.3704  0.5237
     1.2893  1.0873  1.7814
    [torch.FloatTensor of size 5x3]


.. note::
    Any operation that mutates a tensor in-place is post-fixed with an ``_``.
    For example: ``x.copy_(y)``, ``x.t_()``, will change ``x``.

You can use standard NumPy-like indexing with all bells and whistles!



.. code-block:: python


    print(x[:, 1])





.. rst-class:: sphx-glr-script-out

 Out::

    0.5228
     0.0918
     0.9017
     0.0736
     0.4071
    [torch.FloatTensor of size 5]


Resizing: If you want to resize/reshape tensor, you can use ``torch.view``:



.. code-block:: python

    x = torch.randn(4, 4)
    y = x.view(16)
    z = x.view(-1, 8)  # the size -1 is inferred from other dimensions
    print(x.size(), y.size(), z.size())





.. rst-class:: sphx-glr-script-out

 Out::

    torch.Size([4, 4]) torch.Size([16]) torch.Size([2, 8])


**Read later:**


  100+ Tensor operations, including transposing, indexing, slicing,
  mathematical operations, linear algebra, random numbers, etc.,
  are described
  `here <http://pytorch.org/docs/torch>`_.

NumPy Bridge
------------

Converting a Torch Tensor to a NumPy array and vice versa is a breeze.

The Torch Tensor and NumPy array will share their underlying memory
locations, and changing one will change the other.

Converting a Torch Tensor to a NumPy Array
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^



.. code-block:: python


    a = torch.ones(5)
    print(a)





.. rst-class:: sphx-glr-script-out

 Out::

    1
     1
     1
     1
     1
    [torch.FloatTensor of size 5]



.. code-block:: python



    b = a.numpy()
    print(b)





.. rst-class:: sphx-glr-script-out

 Out::

    [1. 1. 1. 1. 1.]


See how the numpy array changed in value.



.. code-block:: python


    a.add_(1)
    print(a)
    print(b)





.. rst-class:: sphx-glr-script-out

 Out::

    2
     2
     2
     2
     2
    [torch.FloatTensor of size 5]

    [2. 2. 2. 2. 2.]


Converting NumPy Array to Torch Tensor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
See how changing the np array changed the Torch Tensor automatically



.. code-block:: python


    import numpy as np
    a = np.ones(5)
    b = torch.from_numpy(a)
    np.add(a, 1, out=a)
    print(a)
    print(b)





.. rst-class:: sphx-glr-script-out

 Out::

    [2. 2. 2. 2. 2.]

     2
     2
     2
     2
     2
    [torch.DoubleTensor of size 5]


All the Tensors on the CPU except a CharTensor support converting to
NumPy and back.

CUDA Tensors
------------

Tensors can be moved onto GPU using the ``.cuda`` method.



.. code-block:: python


    # let us run this cell only if CUDA is available
    if torch.cuda.is_available():
        x = x.cuda()
        y = y.cuda()
        x + y






**Total running time of the script:** ( 0 minutes  0.004 seconds)



.. only :: html

 .. container:: sphx-glr-footer


  .. container:: sphx-glr-download

     :download:`Download Python source code: tensor_tutorial.py <tensor_tutorial.py>`



  .. container:: sphx-glr-download

     :download:`Download Jupyter notebook: tensor_tutorial.ipynb <tensor_tutorial.ipynb>`


.. only:: html

 .. rst-class:: sphx-glr-signature

    `Gallery generated by Sphinx-Gallery <https://sphinx-gallery.readthedocs.io>`_
